import xbmcgui, xbmcplugin, xbmcaddon, sys, urllib.parse, json, urllib.request, re

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
# Link danh sách của bạn
DATA_URL = "https://raw.githubusercontent.com/thung65/plugin.video.fpttv/refs/heads/master/data.json"

def build_menu():
    xbmcplugin.setContent(HANDLE, 'folders')
    try:
        req = urllib.request.Request(DATA_URL, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            data = json.loads(response.read().decode('utf-8'))
        
        # 1. HIỆN MỤC 'ALL' ĐẦU TIÊN
        for item in data:
            if "ALL" in item['name'].upper():
                add_dir(item)

        # 2. HIỆN CÁC MỤC KHÁC (NẾU CÓ, TRỪ INTERNATIONAL)
        for item in data:
            if all(x not in item['name'].upper() for x in ["ALL", "INTERNATIONAL"]):
                add_dir(item)

        # 3. HIỆN MỤC 'INTERNATIONAL' CUỐI CÙNG
        for item in data:
            if "INTERNATIONAL" in item['name'].upper():
                add_dir(item)
                
    except:
        xbmcgui.Dialog().ok("Thông báo", "Không thể nạp dữ liệu từ GitHub")
    xbmcplugin.endOfDirectory(HANDLE)

def add_dir(item):
    li = xbmcgui.ListItem(label=f"[B][COLOR {item['color']}]{item['name']}[/COLOR][/B]")
    li.setArt({'icon': item['icon'], 'thumb': item['icon'], 'fanart': 'fanart.jpg'})
    u = urllib.parse.urlencode({'url': item['url'], 'color': item['color']})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{u}", li, True)

def get_channels(url, color):
    xbmcplugin.setContent(HANDLE, 'videos')
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            content = response.read().decode('utf-8')
        matches = re.findall(r'#EXTINF:.*?(?:tvg-logo="(.*?)")?.*?,(.*?)\n(http.*?)$', content, re.MULTILINE)
        for logo, name, link in matches:
            li = xbmcgui.ListItem(label=f"[COLOR {color}]{name.strip()}[/COLOR]")
            img = logo if (logo and logo.startswith('http')) else "icon.png"
            li.setArt({'icon': img, 'thumb': img, 'fanart': 'fanart.jpg'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, link, li, False)
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

# Điều hướng chính
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
if not params:
    build_menu()
else:
    get_channels(params.get('url'), params.get('color'))