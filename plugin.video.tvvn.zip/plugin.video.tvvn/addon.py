import xbmcgui, xbmcplugin, xbmcaddon, sys, urllib.request, os, xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

ICON_LOCAL = os.path.join(ADDON_PATH, 'icon.png')
FANART_LOCAL = os.path.join(ADDON_PATH, 'fanart.jpg')

def run():
    xbmcplugin.setContent(HANDLE, 'videos')
    url = "https://raw.githubusercontent.com/thung65/Iptv-vietnam/refs/heads/main/fpt"
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        content = urllib.request.urlopen(req).read().decode('utf-8')
        lines = content.split('\n')

        vietnam_items = []
        international_items = []

        for i in range(len(lines)):
            line = lines[i].strip()
            if line.startswith('#EXTINF'):
                # Tách Logo
                logo = ICON_LOCAL
                if 'tvg-logo="' in line:
                    logo = line.split('tvg-logo="')[1].split('"')[0]
                elif 'tvg-logo=' in line: # Trường hợp không có dấu ngoặc kép
                    logo = line.split('tvg-logo=')[1].split(' ')[0].split(',')[0]
                
                # Tách Tên
                name = line.split(',')[-1].strip()
                
                # Tách Link
                if i + 1 < len(lines):
                    link = lines[i+1].strip()
                    if link.startswith('http'):
                        item = {'name': name, 'url': link, 'logo': logo}
                        
                        # PHÂN LOẠI: All ở đầu, International ở cuối
                        # Lọc các kênh quốc tế dựa trên tên
                        if any(x in name.upper() for x in ["INT", "QUỐC TẾ", "GLOBAL", "K+", "K PLUS"]):
                            international_items.append(item)
                        else:
                            vietnam_items.append(item)

        # Gộp danh sách: All trước, International sau
        final_list = vietnam_items + international_items

        for channel in final_list:
            li = xbmcgui.ListItem(label=f"[B]{channel['name']}[/B]")
            
            # Kỹ thuật ép nạp Logo: Thêm '|User-Agent' vào sau link ảnh
            # Đây là bí kíp để các link logo từ GitHub/Web hiện lên được
            img_path = channel['logo']
            if img_path.startswith('http'):
                img_path += '|User-Agent=Mozilla/5.0'

            li.setArt({
                'icon': img_path,
                'thumb': img_path,
                'poster': img_path,
                'fanart': FANART_LOCAL
            })
            
            li.setInfo('video', {'title': channel['name']})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, channel['url'], li, False)
            
    except:
        pass
        
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

if __name__ == '__main__':
    run()